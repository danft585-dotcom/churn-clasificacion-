# Modelado y Evaluación de Clasificación — Predicción de Churn

## Descripción del problema

El **churn** es la pérdida de clientes: personas que dejan de usar un servicio. En este proyecto se entrena un modelo de **clasificación binaria** que predice si un cliente de una empresa de telecomunicaciones abandonará el servicio (`Churn = Yes`) o no, para que la empresa pueda aplicar acciones de retención a tiempo.

- **Dataset:** [Telco Customer Churn (IBM)](https://github.com/IBM/telco-customer-churn-on-icp4d) — 7.043 clientes, 20 variables (datos demográficos, servicios contratados, tipo de contrato, facturación). Incluido en `data/telco_churn.csv`.
- **Modelo:** Regresión Logística (`LogisticRegression`) dentro de un `Pipeline` de scikit-learn con `StandardScaler` y `OneHotEncoder`.
- **División:** 80% entrenamiento / 20% prueba, estratificada por la variable objetivo.

## Estructura del repositorio

```
├── data/
│   └── telco_churn.csv          # Dataset
├── modelado_metricas.ipynb      # Notebook: carga, división, entrenamiento y métricas
├── requirements.txt             # Dependencias
├── .gitignore
└── README.md
```

## Instrucciones de ejecución

1. Clonar el repositorio:
   ```bash
   git clone https://github.com/<tu-usuario>/churn-clasificacion.git
   cd churn-clasificacion
   ```
2. (Opcional) Crear y activar un entorno virtual:
   ```bash
   python -m venv venv
   source venv/bin/activate        # En Windows: venv\Scripts\activate
   ```
3. Instalar dependencias:
   ```bash
   pip install -r requirements.txt
   ```
4. Abrir y ejecutar el notebook:
   ```bash
   jupyter notebook modelado_metricas.ipynb
   ```
   Luego ir a **Kernel → Restart & Run All**. También se puede abrir en VS Code o Google Colab (subiendo la carpeta `data/`).

## Resumen de resultados

Métricas sobre el set de prueba (1.409 clientes), umbral 0,5:

| Métrica   | Valor |
|-----------|-------|
| Accuracy  | 0,806 |
| Precision | 0,657 |
| Recall    | 0,559 |
| F1-Score  | 0,604 |

**Matriz de confusión:**

|                    | Predicho: No churn | Predicho: Churn |
|--------------------|-------------------:|----------------:|
| **Real: No churn** | 926 (VN)           | 109 (FP)        |
| **Real: Churn**    | 165 (FN)           | 209 (VP)        |

### Conclusión

La métrica más importante para este problema es el **Recall**, porque un **falso negativo** (un cliente que se va sin que el modelo lo detecte) implica perder al cliente y todos sus ingresos futuros, mientras que un falso positivo solo cuesta una acción de retención innecesaria.

Con el umbral por defecto, el modelo no detecta a 165 de los 374 clientes que se van (Recall 0,56). **Bajando el umbral a 0,3, el Recall sube a 0,75** y los clientes no detectados bajan a 92, a cambio de más falsas alarmas (Precision 0,52). Para una campaña de retención de bajo costo, ese intercambio es conveniente. El análisis completo está en la última sección del notebook.
